package bean;

/**
 * @Author:Tang
 * @Description:
 * @Date:Created in 2018/4/16-15:19
 * Modified By:
 */
public class ZBean {
    String area;
    String url;
    String urlList;
    String title;
    String content;
    String publishDate;


    String projectCode;
    String ccgpUrl;
    String ccgpHtml;
    String addTime;


    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getPublishDate() {
        return publishDate;
    }

    public void setPublishDate(String publishDate) {
        this.publishDate = publishDate;
    }


    public String getArea() {
        return area;
    }

    public void setArea(String area) {
        this.area = area;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getUrlList() {
        return urlList;
    }

    public void setUrlList(String urlList) {
        this.urlList = urlList;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getProjectCode() {
        return projectCode;
    }

    public void setProjectCode(String projectCode) {
        this.projectCode = projectCode;
    }

    public String getCcgpUrl() {
        return ccgpUrl;
    }

    public void setCcgpUrl(String ccgpUrl) {
        this.ccgpUrl = ccgpUrl;
    }

    public String getCcgpHtml() {
        return ccgpHtml;
    }

    public void setCcgpHtml(String ccgpHtml) {
        this.ccgpHtml = ccgpHtml;
    }

    public String getAddTime() {
        return addTime;
    }

    public void setAddTime(String addTime) {
        this.addTime = addTime;
    }




}
