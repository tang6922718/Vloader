package bean;

/**
 * @Author:Tang
 * @Description:
 * @Date:Created in 2018/4/4-9:55
 * Modified By:
 */
public class JYuan {
    String id;

    public String getId() {
        return id;
    }

    public void setId(String id) {
        this.id = id;
    }
}
