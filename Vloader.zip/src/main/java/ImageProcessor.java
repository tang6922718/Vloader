
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Request;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.utils.HttpConstant;

import java.util.*;

public class ImageProcessor implements PageProcessor {



    // 部分一：抓取网站的相关配置，包括编码、抓取间隔、重试次数等
    private Site site = Site.me()
            .setRetryTimes(3)
            .setDomain("http://search.jiayuan.com/v2")
            .setUserAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36")
            .setSleepTime(1000)
            .setCharset("utf-8")
            .addCookie("cookie","guider_quick_search=on; myuid=174989198; is_searchv2=1; save_jy_login_name=625089324; PHPSESSID=4ce5eba165a2846c7234ca44d6898f2c; SESSION_HASH=133ce36eee3dc6a0c5d9bd1b3ec98c0e55b745cb; user_access=1; stadate1=174989198; myloc=51%7C5117; myage=26; PROFILE=175989198%3A%25E7%25BB%2585%25E5%25A3%25AB%3Am%3Aat1.jyimg.com%2Fc5%2F5f%2Fbd5883f228e3eb0244732543e8df%3A1%3A%3A1%3Abd5883f22_1_avatar_p.jpg%3A1%3A1%3A50%3A10; mysex=m; myincome=30; COMMON_HASH=c5bd5883f228e3eb0244732543e8df5f; pclog=%7B%22175989198%22%3A%221523154818618%7C1%7C0%22%7D; IM_S=%7B%22IM_CID%22%3A2883986%2C%22IM_SV%22%3A%22123.59.161.5%22%2C%22svc%22%3A%7B%22code%22%3A0%2C%22nps%22%3A0%2C%22unread_count%22%3A%2246%22%2C%22ocu%22%3A0%2C%22ppc%22%3A0%2C%22jpc%22%3A0%2C%22regt%22%3A%221522723703%22%2C%22using%22%3A%22%22%2C%22user_type%22%3A%2210%22%2C%22uid%22%3A175989198%7D%2C%22m%22%3A39%2C%22f%22%3A0%2C%22omc%22%3A0%7D; main_search:175989198=%7C%7C%7C00; RAW_HASH=pyF%2APNv5dJ5876QjnoM2HYdbqP4FPlCqFjshaZHMDGtxNGVX52fSS6Z9sZAesboYcF9%2A6goyRzdnxlwl4yeJVAxhvH9wKpZtJRwA8V-lJDyeikw.; pop_time=1523158540509; IM_CON=%7B%22IM_TM%22%3A1523158543827%2C%22IM_SN%22%3A4%7D; IM_M=%5B%5D; IM_TK=1523158577520; IM_CS=2; IM_ID=5");

    public void process(Page page) {
        Set set = new HashSet<String>();
        for (int i=1;i<=5;i++) {
            Request request = this.requestDel(String.valueOf(i));
            page.setRequest(request);
            page.addTargetRequest(request);
        }
       //2.抓取数据
      String [] urlImage=page.getHtml().regex("\"image\":.*?jpg").regex("http.*?jpg").all().toString().replaceAll("[\\[\\]]","").split(",");
        for (int i=0;i<urlImage.length;i++){
            set.add(urlImage[i]);
        }


        //        SjDao.insertID(page.getHtml().regex("\"uid\":\\d+,").regex("\\d+").all().toString().replaceAll("[\\[\\]]",""));
        System.out.println(set);


    }

    public Site getSite() {
        return site;
    }

    private List<String> saveNewsListData(String pageUrl,String pindaoId) {
            return null;
    }

    private  Request   requestDel(String pageNum){

        //设置POST请求
        Request request = new Request("http://search.jiayuan.com/v2/search_v2.php");
        //只有POST请求才可以添加附加参数
        request.setMethod(HttpConstant.Method.POST);

        //设置POST参数
        List<NameValuePair> nvs = new ArrayList<NameValuePair>();
        nvs.add(new BasicNameValuePair("sex", "f"));
        nvs.add(new BasicNameValuePair("key", ""));
        nvs.add(new BasicNameValuePair("stc", "2:18.30,3:155.170,23:1"));
        nvs.add(new BasicNameValuePair("sn", "default"));
        nvs.add(new BasicNameValuePair("sv", "1"));
        nvs.add(new BasicNameValuePair("p", pageNum));

        nvs.add(new BasicNameValuePair("f", ""));
        nvs.add(new BasicNameValuePair("listStyle", "bigPhoto"));
        nvs.add(new BasicNameValuePair("pri_uid", "175989198"));
        nvs.add(new BasicNameValuePair("jsversion", "v5"));
        //转换为键值对数组
        NameValuePair[] values = nvs.toArray(new NameValuePair[] {});
        //将键值对数组添加到map中
        Map<String, Object> params = new HashMap<String, Object>();
        //key必须是：nameValuePair
        params.put("nameValuePair", values);

        //设置request参数
        request.setExtras(params);
        request.addCookie("cookies","guider_quick_search=on; myuid=174989198; is_searchv2=1; save_jy_login_name=625089324; PHPSESSID=4ce5eba165a2846c7234ca44d6898f2c; SESSION_HASH=133ce36eee3dc6a0c5d9bd1b3ec98c0e55b745cb; user_access=1; stadate1=174989198; myloc=51%7C5117; myage=26; PROFILE=175989198%3A%25E7%25BB%2585%25E5%25A3%25AB%3Am%3Aat1.jyimg.com%2Fc5%2F5f%2Fbd5883f228e3eb0244732543e8df%3A1%3A%3A1%3Abd5883f22_1_avatar_p.jpg%3A1%3A1%3A50%3A10; mysex=m; myincome=30; COMMON_HASH=c5bd5883f228e3eb0244732543e8df5f; pclog=%7B%22175989198%22%3A%221523154818618%7C1%7C0%22%7D; IM_S=%7B%22IM_CID%22%3A2883986%2C%22IM_SV%22%3A%22123.59.161.5%22%2C%22svc%22%3A%7B%22code%22%3A0%2C%22nps%22%3A0%2C%22unread_count%22%3A%2246%22%2C%22ocu%22%3A0%2C%22ppc%22%3A0%2C%22jpc%22%3A0%2C%22regt%22%3A%221522723703%22%2C%22using%22%3A%22%22%2C%22user_type%22%3A%2210%22%2C%22uid%22%3A175989198%7D%2C%22m%22%3A39%2C%22f%22%3A0%2C%22omc%22%3A0%7D; main_search:175989198=%7C%7C%7C00; RAW_HASH=pyF%2APNv5dJ5876QjnoM2HYdbqP4FPlCqFjshaZHMDGtxNGVX52fSS6Z9sZAesboYcF9%2A6goyRzdnxlwl4yeJVAxhvH9wKpZtJRwA8V-lJDyeikw.; pop_time=1523158540509; IM_CON=%7B%22IM_TM%22%3A1523158543827%2C%22IM_SN%22%3A4%7D; IM_M=%5B%5D; IM_TK=1523158577520; IM_CS=2; IM_ID=5");


         return request;
    }

}
