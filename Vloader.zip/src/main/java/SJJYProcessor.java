import bean.JYuan;
import dao.SjDao;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.processor.PageProcessor;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;
import java.util.concurrent.ExecutorService;
import java.util.concurrent.Executors;

public class SJJYProcessor implements PageProcessor {
    // 部分一：抓取网站的相关配置，包括编码、抓取间隔、重试次数等
    private Site site = Site.me()
            .setRetryTimes(3)
            .setDomain("http://www.jiayuan.com")
            .setUserAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36")
            .setSleepTime(1000)
            .setCharset("utf-8")
            .addCookie("cookie","guider_quick_search=on; myuid=174989198; is_searchv2=1; save_jy_login_name=625089324; stadate1=174989198; myloc=51%7C5117; myage=26; mysex=m; myincome=30; SESSION_HASH=6fc1a0c640e02ccc07d2ddea4dbdab3d4207e8f5; user_access=1; PROFILE=175989198%3A%25E7%25BB%2585%25E5%25A3%25AB%3Am%3Aat1.jyimg.com%2Fc5%2F5f%2Fbd5883f228e3eb0244732543e8df%3A1%3A%3A1%3Abd5883f22_1_avatar_p.jpg%3A1%3A1%3A50%3A10; COMMON_HASH=c5bd5883f228e3eb0244732543e8df5f; last_login_time=1522805044; pclog=%7B%22175989198%22%3A%221522805027344%7C1%7C0%22%7D; IM_S=%7B%22IM_CID%22%3A2546156%2C%22IM_SV%22%3A%22123.59.161.5%22%2C%22svc%22%3A%7B%22code%22%3A0%2C%22nps%22%3A0%2C%22unread_count%22%3A%2210%22%2C%22ocu%22%3A0%2C%22ppc%22%3A0%2C%22jpc%22%3A0%2C%22regt%22%3A%221522723703%22%2C%22using%22%3A%22%22%2C%22user_type%22%3A%2210%22%2C%22uid%22%3A175989198%7D%2C%22m%22%3A2%2C%22f%22%3A0%2C%22omc%22%3A0%7D; PHPSESSID=e2bbb85746691be09e161887fa3a093f; main_search:175989198=%7C%7C%7C00; buyhistory_v2=%257B%252242%2522%253A%257B%2522pid%2522%253A%252242%2522%252C%2522url%2522%253A%2522%255C%252Fusercp%255C%252Fservice%255C%252Fdo_package_service.php%253Frid%253D1532%2522%252C%2522pname%2522%253A%2522%255Cu94bb%255Cu77f3%255Cu4f1a%255Cu545812%255Cu4e2a%255Cu6708%255Cu7acb%255Cu51cf300%255Cu5143%2522%252C%2522time%2522%253A1522813535%257D%257D; IM_CON=%7B%22IM_TM%22%3A1522818109169%2C%22IM_SN%22%3A5%7D; IM_M=%5B%5D; pop_time=1522820981648; RAW_HASH=ZREwNBNDDFDddiIVIfi%2ACajcvdTtWx33I0choOXiKjDxAlZ8DVavQRHbyVpnlXT1%2AR3HZOy82vE6oZHG-lcmxiQkEBnFQ3eIQZzVYtYCTWQ3ziE.; IM_TK=1522821146659; IM_CS=2; IM_ID=12");

    public void process(Page page) {
        //编写抓取逻//1.获得详情页urlist<String> list =new ArrayList<>();
        for(int i=1;i<=10000;i++) {
            page.addTargetRequest("http://search.jiayuan.com/v2/search_v2.php?sex=f&key=&stc=2%3A18.30%2C3%3A155.170%2C23%3A1&sn=default&sv=1&p="+i+"&f=&listStyle=bigPhoto&pri_uid=175989198&jsversion=v5");
        }
       //2.抓取数据

//        SjDao.insertID(page.getHtml().regex("\"uid\":\\d+,").regex("\\d+").all().toString().replaceAll("[\\[\\]]",""));
        System.out.println(page.getHtml().regex("\"uid\":\\d+,").regex("\\d+").all().toString().replaceAll("[\\[\\]]",""));


    }

    public Site getSite() {
        return site;
    }

    private List<String> saveNewsListData(String pageUrl,String pindaoId) {
            return null;
    }
}
