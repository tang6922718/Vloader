package processor;

import bean.WinBidBean;
import bean.ZBean;
import dao.ZBDao2;
import org.apache.http.NameValuePair;
import org.apache.http.message.BasicNameValuePair;
import org.jsoup.Jsoup;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.WebElement;
import test.FantomJs;
import test.ReMatcher;
import test.SearchProjectNum;
import us.codecraft.webmagic.Page;
import us.codecraft.webmagic.Request;
import us.codecraft.webmagic.Site;
import us.codecraft.webmagic.model.HttpRequestBody;
import us.codecraft.webmagic.processor.PageProcessor;
import us.codecraft.webmagic.utils.HttpConstant;

import javax.xml.bind.Element;
import java.io.UnsupportedEncodingException;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.*;

public class ZBProcessor1 implements PageProcessor {
    // 部分一：抓取网站的相关配置，包括编码、抓取间隔、重试次数等
    private Site site = Site.me()
            .setRetryTimes(3)
            .setUserAgent("Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36")
            .setSleepTime(1000)
            .setCharset("utf-8");
    String helperUrl = "http://www.hcggzy.cn/gxhczbw/showinfo/zbgsmore.aspx";
    String targetUrl = "/gx.*&CategoryNum=\\d+";
    DateFormat dFormat = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss"); //HH表示24小时制；
    String nowDate = dFormat.format(new Date());
    List<String> list = new ArrayList<>();
    Map map = new HashMap();
    public static int pageNum = 1;
    public Boolean flag = true;//收集post请求只进入一次

    public void process(Page page) {
        //编写抓取逻辑
        //收集详情页url
        if (page.getUrl().regex(helperUrl).match()) {
//            System.out.println(page.getHtml().xpath("//*[@id=\"MoreInfoListZbgs1_moreinfo\"]").all().toString());
            Request request = new Request("http://www.hcggzy.cn/gxhczbw/showinfo/zbgsmore.aspx");
            request.setMethod(HttpConstant.Method.POST);
            try {
                map.put("__VIEWSTATE",page.getHtml().xpath("//input[@id=\"__VIEWSTATE\"]/@value").toString());
                map.put("__EVENTTARGET","MoreInfoListZbgs1$Pager");
                map.put("__EVENTARGUMENT",pageNum);
                map.put("__VIEWSTATEENCRYPTED","");
                request.setRequestBody(HttpRequestBody.form(map, "utf-8"));
                request.addHeader("Cookie", "_gscu_1934329613=21010163bmserw11; yunsuo_session_verify=e51270d4715b27e4c6b8731a0e2b1b15; ASP.NET_SessionId=3wdoymni0eptiv55my52zv45; _gscbrs_1934329613=1; _gscs_1934329613=24100802qked8320|pv:12");
//                request.addHeader("Content-Type", "application/x-www-form-urlencoded");
//                request.addHeader("Host", "www.hcggzy.cn");
//                request.addHeader("User-Agent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36");
//                request.addHeader("Upgrade-Insecure-Requests", "1");
//                request.addHeader("Referer", "http://www.hcggzy.cn/gxhczbw/showinfo/zbgsmore.aspx");
//                request.addHeader("Accept", "text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8");
                page.addTargetRequest(request);
                pageNum++;
                System.out.println("当前页码---》"+pageNum);
            } catch (UnsupportedEncodingException e) {
                e.printStackTrace();
            }
            List<String> listUrl = page.getHtml().xpath("//*[@id=\"MoreInfoListZbgs1_moreinfo\"]").links().regex(targetUrl).all();
            page.addTargetRequests(listUrl);
        }
       // 抽取数据
        if (page.getUrl().regex(targetUrl).match()) {
            String title = page.getHtml().xpath("//*[@id='lblTitle']//text()").toString();
            String content = page.getHtml().$("#tblInfo","allText").toString();
            String num = ReMatcher.reOne(content, "[A-Z0-9-\\[\\]]{4,}").toString();
            String url = page.getUrl().toString();
            Map map = SearchProjectNum.search(num);

                WinBidBean winBidBean = new WinBidBean();
                winBidBean.setArea("");
                winBidBean.setAddTime(nowDate);
                winBidBean.setUrl(url);
                winBidBean.setContent(content);
                winBidBean.setProjectCode(num);

                winBidBean.setTitle(title);
                winBidBean.setUrlList("");
                winBidBean.setPublishDate("");
                winBidBean.setWebsiteCity("河池市");
                winBidBean.setWebsiteSource("16");

                winBidBean.setRead_label("0");
                winBidBean.setValue2("");

            if (map != null) {
                winBidBean.setCcgpHtml(map.get("ccgpHtml").toString());
                winBidBean.setCcgpUrl(map.get("ccgpUrl").toString());
            } else {
                winBidBean.setCcgpHtml("");
                winBidBean.setCcgpUrl("");
            }

            ZBDao2.insertWinBidInfo(winBidBean);
        }


    }

    public Site getSite() {
        return site;
    }

    private List<String> saveNewsListData(String pageUrl, String pindaoId) {
        return null;
    }

//    oprationDriver
}
