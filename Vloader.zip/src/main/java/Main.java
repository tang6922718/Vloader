
import processor.ZBPageProcessor;
import processor.ZBProcessor1;
import us.codecraft.webmagic.Request;
import us.codecraft.webmagic.Spider;
import us.codecraft.webmagic.model.HttpRequestBody;
import us.codecraft.webmagic.pipeline.ConsolePipeline;
import us.codecraft.webmagic.utils.HttpConstant;

import java.io.UnsupportedEncodingException;


public class Main {

    public static void main(String[] args) {
        Spider spider = Spider.create(new ZBProcessor1()).addPipeline(new ConsolePipeline());
        spider.addUrl("http://www.hcggzy.cn/gxhczbw/showinfo/zbgsmore.aspx");
        spider.thread(1).start();
    }



}
