package test;


import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;


/**
 * @Author:Tang
 * @Description:
 * @Date:Created in 2018/4/18-15:58
 * Modified By:
 */
public class WebDriver {

    org.openqa.selenium.WebDriver driver;

    public org.openqa.selenium.WebDriver operation() {
        System.setProperty("webdriver.chrome.driver", "C:/dev/chromedriver.exe");
        ChromeDriver driver = new ChromeDriver();
        return driver;
    }

    public static void main(String[] args) throws InterruptedException {


        WebDriver driver = new WebDriver();
        org.openqa.selenium.WebDriver webDriver1 = driver.operation();
        webDriver1.get("http://www.hcggzy.cn/gxhczbw/showinfo/zbgsmore.aspx");
        int i=1;
        while (i<5){
            webDriver1.findElement(By.xpath("//img[@src=\"/gxhczbw/images/page/nextn.gif\"]")).click();
        }
        Thread.sleep(3000);
        webDriver1.quit();

    }
}
