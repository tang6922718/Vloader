package test;

import org.junit.jupiter.api.Test;
import org.openqa.selenium.By;
import org.openqa.selenium.WebDriver;
import org.openqa.selenium.phantomjs.PhantomJSDriver;
import org.openqa.selenium.remote.DesiredCapabilities;

/**
 * @Author:Tang
 * @Description:
 * @Date:Created in 2018/4/4-15:48
 * Modified By:
 */
public class FantomJs {
    WebDriver driver;

   public WebDriver operation(){
       System.setProperty("phantomjs.binary.path", "C:\\phantomjs-2.1.1-windows\\bin\\phantomjs.exe");
       DesiredCapabilities desiredCapabilities =new DesiredCapabilities();
       desiredCapabilities.setCapability("phantomjs.page.settings.userAgent", "Mozilla/5.0 (Windows NT 6.1; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/63.0.3239.132 Safari/537.36");
       desiredCapabilities.setCapability("phantomjs.page.settings.loadImages",false);
       desiredCapabilities.setCapability("acceptSslCerts", true);
       //截屏支持
       desiredCapabilities.setCapability("loadImage", false);
       //css搜索支持
       desiredCapabilities.setCapability("cssSelectorsEnabled", true);
       //js支持
       desiredCapabilities.setJavascriptEnabled(true);
       driver= new PhantomJSDriver(desiredCapabilities);
       return driver;
    }
}
