package test;

import org.junit.jupiter.api.Test;

/**
 * @Author:Tang
 * @Description:
 * @Date:Created in 2018/3/28-15:46
 * Modified By:
 */
public class TestUtil {


    //合并表操作
    @Test
    public void test(){
        String selectSql = "SELECT * FROM admin_gx_full0329  GROUP BY url_2 HAVING (COUNT(url_2))>1";
        String insertSql="insert into admin_gx_full0329 values (?,?,?,?,?)  ";
        String delSql="delete from admin_gx_full0329 where url_2=?";
        DbUtil dbUtil = new DbUtil();
        //第一层循环查询数据，第二层循环插入数据
        dbUtil.MysqlHB(selectSql,insertSql,delSql);
    }


}
