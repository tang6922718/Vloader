package test;

import bean.ZBean;
import com.alibaba.druid.pool.DruidPooledConnection;
import db.ServerDBConnection;

import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;

/**
 * @Author:Tang
 * @Description:
 * @Date:Created in 2018/3/14-10:27
 * Modified By:
 */
public class DbUtil {

//    public static int MysqlUpdate1(String  sql , ZBean zBean) {
//        try {
//            try (DruidPooledConnection connection = ServerDBConnection.INSTANCE.getConnection();
//                 PreparedStatement pst = connection.prepareStatement(sql)) {
//
//                for (int i=1;i<=8;i++){
//                    pst.setString(i,);
//                }
//                return pst.executeUpdate();
//
//            }
//        } catch (SQLException e) {
//            e.printStackTrace();
//        }
//        return 0;
//    }
//


    public static int MysqlUpdate(String  sql , String ... param) {
        try {
            try (DruidPooledConnection connection = ServerDBConnection.INSTANCE.getConnection();
                 PreparedStatement pst = connection.prepareStatement(sql)) {

               for (int i=1;i<=param.length;i++){
                   pst.setString(i,param[i-1]);
               }
               return pst.executeUpdate();

            }
        } catch (SQLException e) {
            System.out.println("数据操作异常--》"+e.getMessage());
        }
        return 0;
    }
    public static boolean MysqlExceute(String  sql , String ... param) {
        try {
            try (DruidPooledConnection connection = ServerDBConnection.INSTANCE.getConnection();
                 PreparedStatement pst = connection.prepareStatement(sql)) {
                for (int i=1;i<=param.length;i++){
                    pst.setString(i,param[i-1]);
                }
                return pst.execute();

            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return false;
    }


    //合并表
    public int MysqlHB(String  selectSql ,String insertSql, String delSql,String ... param) {
        try {
            try (DruidPooledConnection connection = ServerDBConnection.INSTANCE.getConnection();
                 PreparedStatement pst = connection.prepareStatement(selectSql);
                 PreparedStatement pst1 = connection.prepareStatement(insertSql);
                 PreparedStatement pst2 = connection.prepareStatement(delSql)
                 ) {

                ResultSet resultSet=pst.executeQuery();
                while (resultSet.next()){

                    pst2.setString(1,resultSet.getString("url_2"));
                    pst2.executeUpdate();

                    pst1.setString(1,resultSet.getString("area"));
                    pst1.setString(2,resultSet.getString("url_2"));
                    pst1.setString(3,resultSet.getString("url_1"));
                    pst1.setString(4,resultSet.getString("content"));
                    pst1.setString(5,resultSet.getString("sub_num"));
                    pst1.executeUpdate();

                    System.out.println("成功去重一条数据。！！！");
                   /* pst1.setString(1, resultSet.getString("project_code"));
                    pst1.setString(2, resultSet.getString("ccgp_url"));
                    pst1.setString(3, resultSet.getString("ccgp_html"));
                    pst1.setString(4, resultSet.getString("add_time"));
                    pst1.setString(5, resultSet.getString("project_code"));
                    pst1.executeUpdate();
                    System.out.println("找到一条数据。！！！");*/
                }



            }
        } catch (SQLException e) {
            e.printStackTrace();
        }
        return 0;
    }
}


